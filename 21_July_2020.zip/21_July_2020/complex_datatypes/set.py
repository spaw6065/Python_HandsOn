set1={"Green","Blue","Yellow"}

set1.add("Pink")
print(set1)

set1.remove("Green")
print(set1)

set1.pop()
print(set1)

set2=set()

set3 = {5,6,"Blue"}

x = {"apple", "banana", "cherry"}
y = {"google", "microsoft", "apple"}

x.update(y)

print(x)