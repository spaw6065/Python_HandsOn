str1="2"
print(bool(str1))

if len(str1) == 0:
    print("str1 string is empty")
else:
    print("str1 string is set to",str1)

print(isinstance(str1,str))    